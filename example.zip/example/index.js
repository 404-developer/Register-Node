const express = require('express');
const app = express();
// // useroverall_routes
const userfinal = require('./app/controller/usercontrol')

app.use(express.json());
require('dotenv').config()

// // overallroutes

app.use('/user', userfinal)

app.listen(process.env.PORT, () => {
    console.log('Server is starting = ' +process.env.PORT);
});

