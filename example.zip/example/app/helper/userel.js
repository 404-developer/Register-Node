//customise function//
const jwt = require("jsonwebtoken");
const Cryptr = require("cryptr");
const cryptr = new Cryptr("myTotalySecretKey");
const userexp = require("../model/usertype");

// secretkey_generate_your_input_start
const ukey = require("crypto").randomBytes(20).toString("hex");
const methods = require("../middleware/userval");
const moment = require("moment");
const otpGenerator = require("otp-generator");


var tokenvalidate;
var otptime;
var otpel = otpGenerator.generate(6, {
  upperCaseAlphabets: false,
  specialChars: false,
  lowerCaseAlphabets: false,
});

// user_registration_method
exports.userreg = (req, res) => {

  const us = new userexp();
  const account = web3.eth.accounts.create();
  const addressel = account.address;
  const privateKey = account.privateKey;
  const encryptedString = cryptr.encrypt(req.body.password);
  us.email = req.body.email;
  us.password = encryptedString;
  us.username = req.body.username;
  us.walletaddress = addressel;
  us.save(function (err, data) {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      res.status(200).json({
        message: `register success`,
        address: addressel,
        privateKey: privateKey,
      });
    }
  });
};

// userloginmethod

exports.userlog = (req, res) => {
  var Email = req.body.email;
  userexp.findOne({ email: Email }, function (err, datael) {
    if (err) {
      res.status(500).json({ error: err });
    } else if (datael == null) {
      res.status(404).json({ message: `Please Check Your Email` });
    } else {
      const password = cryptr.decrypt(datael.password);
      email = datael.email;
      if (password === req.body.password) {
        const user = methods.covert2obj(Email); //parameterpass
        jwt.sign({ user: user }, ukey, { expiresIn: "60m" }, (err, token) => {
          if (err) {
            res.status(500).json({ error: err });
          } else {
            res.status(200).json({ success: token });
            tokenvalidate = token;
            userexp.updateMany(
              { email: req.body.email },
              { $set: { logintime: dateel } },
              function (err, data) {
                if (err) {
                  res.status(500).json({ error: err });
                } else {
                  loginexp.insertMany(
                    { email: Email, time: dateel },
                    function (err, data) {
                      if (err) {
                        res.status(500).json({ error: err });
                      } else {
                        console.log("update-logintime!");
                      }
                    }
                  );
                }
              }
            );
          }
        });
      } else {
        res.status(404).json({ error: `Incorrect password!` });
      }
    }
  });
};

// jwtauthentication
exports.userverify = (req, res, next) => {
  const bearerHeader = req.headers["authorization"];
  if (typeof bearerHeader !== "undefined") {
    const bearerToken = bearerHeader.split(" ")[1];
    req.token = bearerToken;
    // decodeemail_method
    var dec_email = jwt.decode(req.token);
    var Email = dec_email.user.Email;
    if (tokenvalidate == req.token) {
      jwt.verify(req.token, ukey, function (err, data) {
        if (err) res.json({ status: false, message: err });
        else {
          // middleware use the method
          req.Email = Email;
          next();
        }
      });
    } else {
      res.json({ status: false, message: `Token expired!,login again!` });
    }
  } else {
    res.json({ status: false, message: `Token Empty!` });
  }
};

// userlogout
exports.userlogout = (req, res) => {
  var Email = req.Email;
  userexp.findOneAndUpdate(
    { email: Email },
    { logouttime: dateel },
    function (err, data) {
      if (err) {
        res.status(500).json({ error: err });
      } else {
        tokenvalidate=null
        res.status(200).json({ success: "logout successfully" });
      }
    }
  );
};

var dateel = moment().format("MM/DD/YYYY h:mm:ss a");
exports.userstatus = (req, res) => {
  var Email = req.Email;
  userexp.findOneAndUpdate(
    { email: Email },
    { logouttime: dateel },
    function (err, data) {
      if (err) {
        res.status(500).json({ error: err });
      } else if (data == null) {
        res.status(404).json({ message: "email is not found" });
      } else if (data) {
        var status = data.logouttime;
        var moment1 = moment().add(30, "days").calendar();
        if (status < moment1) {
          userexp.findOneAndUpdate(
            { email: Email },
            { $set: { userstatus: "Active" } },
            function (err, data) {
              if (err) {
                res.status(500).json({ error: err });
              } else {
                res.status(200).json({ success: "update userstatus" });
              }
            }
          );
        } else {
          userexp.findOneAndUpdate(
            { email: Email },
            { $set: { userstatus: "Deactive" } },
            function (err, data) {
              if (err) {
                res.status(500).json({ error: err });
              } else {
                res.status(200).json({ success: "update userstatus" });
              }
            }
          );
        }
      }
    }
  );
};

// userchangepassword
exports.userchangepassword = (req, res) => {
  var Email = req.Email;
  var Password = req.body.password;
  var newpassword = req.body.newpassword;
  userexp.find({ email: Email }, { password: 1 }, function (err, data) {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      const cryptr = new Cryptr("myTotalySecretKey");
      const values = cryptr.decrypt(data[0].password);
      if (values == Password) {
        const store = cryptr.encrypt(newpassword);
        userexp.findOneAndUpdate(
          { email: Email },
          { $set: { password: store } },
          function (err, data) {
            if (err) {
              res.status(500).json({ error: err });
            } else {
              res.status(200).json({ success: "update success" });
            }
          }
        );
      }
    }
  });
};

exports.usermailer = (req, res) => {
  var dateel = moment(Date.now()).format("YYYY-MM-DD HH:mm:ss");
  otptime = dateel;
  const { email } = req.body;
  userexp.findOne({ email: email }, function (err, data) {
    if (err) {
      res.status(500).json({ error: err });
    } else if (data == null) {
      res.status(401).json({ message: "incorrect email" });
    } else if (data.email == email) {
      var transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: process.env.FROMEMAIL,
          pass: process.env.PASSWORD,
        },
      });
      var mailOptions = {
        from: process.env.FROMEMAIL,
        to: process.env.TOEMAIL,
        subject: "Otpverification",
        text: "otp:" + otpel,
      };
      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          res.status(500).json({ error: err });
        } else {
          res.status(200).json({
            success:
              "Email sent: Check your Email & Verify Your Otp & Reset Password =>localhost:8000/user/loginreset",
          });
        }
      });
    }
  });
};

// user_reset_password_method
exports.userreset = (req, res) => {

  var otpstore = moment(Date.now()).format("YYYY-MM-DD HH:mm:ss");
  var calculate = moment(otpstore).diff(otptime, "seconds");
  var otp = req.body.otp;
  if (calculate <= 60) {
    if (otp == otpel) {
      userexp.findOne(
        { email: req.body.email },
        { password: req.body.newpassword },
        function (err, data) {
          if (err) {
            res.status(500).json({ error: err });
          } else {
            const cryptr = new Cryptr("myTotalySecretKey");
            const passel = req.body.newpassword;
            const encryptedString = cryptr.encrypt(passel);
            userexp.findOneAndUpdate(
              { email: req.body.email },
              { $set: { password: encryptedString } },
              function (err, datas) {
                if (err) {
                  res.status(500).json({ error: err });
                } else {
                  res.status(200).json({ success: "password update!" });
                }
              }
            );
          }
        }
      );
    } else {
      res.status(404).json({ message: "Time Expired" });
    }
  } else {
    res.status(404).json({ message: "Incorrect Otp" });
  }
};

