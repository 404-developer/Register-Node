var mongoose = require('../config/config');
var UserSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true,
        unique: true
    },
    firstname: {
        type: String,
    },
    lastname: {
        type: String,
    },
    mobilenumber: {
        type: Number,
    },
    profileimage: {
        type: String,
    },
    aadhaarfrontside: {
        type: String,
    },
    aadhaarbackside: {
        type: String,
    },
    selfie: {
        type: String,
    },
    kycstatus: {
        type: String
    },
    tfastatus: {
        type: Number
    },
    logintime: {
        type: String
    },
    logouttime: {
        type: String
    },
    walletaddress: {
        type: String
    },
    userstatus: {
        type: String
    },
    Balance: {
        type: Number
    },
    BNB: {
        type: Number
    },
    ETH: {
        type: Number
    },
    symbol: {
        type: String
    }
}, { timestamps: true })
module.exports = mongoose.model('User', UserSchema);
