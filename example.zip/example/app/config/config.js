var mongoose=require('mongoose')
url="mongodb://localhost:27017/example";
mongoose.connect(url,(err,db)=>{
    if(err)throw err
    else{
        console.log('db connect')
    }
})

module.exports=mongoose