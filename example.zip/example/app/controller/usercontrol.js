const express = require('express');
const router = express.Router();
const usersource = require('../helper/userel')
// usermiddleware
const { validateuser, username, userpassword,
    newpassword, passwordel,
    userotp, userelValidation,
} = require('../middleware/userval');
// userdetails
router.post('/userregistration', validateuser, username, userpassword, userelValidation, usersource.userreg)
router.post('/userlogin', validateuser, userpassword, userelValidation, usersource.userlog)
router.post('/userlogout', usersource.userverify, usersource.userlogout)
router.post('/userstatus', usersource.userverify, usersource.userstatus)
router.post('/userchangepassword', usersource.userverify, passwordel, newpassword, userelValidation, usersource.userchangepassword)
router.post('/usermailer', validateuser, userelValidation, usersource.usermailer)
router.post('/userloginreset', validateuser, userotp, newpassword, userelValidation, usersource.userreset)

module.exports = router;