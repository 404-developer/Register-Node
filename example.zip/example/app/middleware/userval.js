const { check, body, validationResult } = require("express-validator");
// userValidation
exports.validateuser = [
  check("email")
    .trim()
    .not()
    .isEmpty()
    .withMessage("Email is required")
    .isEmail()
    .normalizeEmail()
    .withMessage("Email Pattern Only"),
];

exports.userpassword = [
  check("password")
    .trim()
    .not()
    .isEmpty()
    .withMessage("Password Empty")
    .isLength({ min: 6, max: 10 })
    .withMessage("Min 6 and Max 10 ")
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.+[0-9][0-9])(?=.*[!@#\$%\^&\*])(?=.{6,10})/)
    .withMessage("min 6 char max 10 char one caps one symbol and 2 number"),

  check("confirmpassword")
    .trim()
    .not()
    .isEmpty()
    .withMessage("Confirmpassword Empty")
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error("confirm password at the same password");
      }
      return true;
    }),
];
exports.passwordel = [
  check("password")
    .trim()
    .not()
    .isEmpty()
    .withMessage("Password Empty")
    .isLength({ min: 6, max: 10 })
    .withMessage("Min 6 and Max 10 ")
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.+[0-9][0-9])(?=.*[!@#\$%\^&\*])(?=.{6,10})/)
    .withMessage("min 6 char max 10 char one caps one symbol and 2 number"),

 
]
exports.newpassword = [
  check("newpassword")
    .trim()
    .not()
    .isEmpty()
    .withMessage("New Password Empty")
    .isLength({ min: 6, max: 10 })
    .withMessage("Min 6 and Max 10 ")
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.+[0-9][0-9])(?=.*[!@#\$%\^&\*])(?=.{6,10})/)
    .withMessage("min 6 char max 10 char one caps one symbol and 2 number"),

 
];
exports.username = [
  check("username")
    .trim()
    .not()
    .isEmpty()
    .withMessage("username Empty")
    .isLength({ min: 5, max: 10 })
    .withMessage("Min 5 and Max 10 "),
];

exports.userotp = [
  check("otp").trim().not().isEmpty().withMessage("Otp Empty!!")

];
exports.firstname = [
  check("firstname").trim().not().isEmpty().withMessage("firstname Empty!!")
    .isLength({ min: 3, max: 15 }).withMessage("Min 5 and Max 15 "),
]
exports.lastname = [
  check("lastname").trim().not().isEmpty().withMessage("lastname Empty!!")
    .isLength({ min: 3, max: 15 }).withMessage("Min 5 and Max 15 "),
]

exports.mobilenumber = [
  check("mobilenumber").trim().not().isEmpty().
    withMessage("mobilenumber Empty!!")
    .isNumeric()
    .withMessage('Numeric field only')
    .isLength({ min: 10, max: 12 }).withMessage("Min 10 and Max 12"),
    

]


exports.covert2obj=function(Email,Pattern)
{
  return {Email,Pattern}
}

exports.userelValidation = (req, res, next) => {
  const result = validationResult(req).array();
  if (!result.length) return next();
  const error = result[0].msg;
  res.json({ success: false, message: error });
};
